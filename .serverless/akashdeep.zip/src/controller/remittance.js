const Remittance = require('../model/remittance'); // Replace the path to the remittance model with your actual file path

// Create a new remittance
exports.createRemittance = async (req, res) => {
  try {
    // Get data from request body
    const { city, optionBestDescribeYou, name, mobile, email, monthlyImport_Export } = req.body;

    // Create a new remittance document
    const remittance = new Remittance({
      city,
      optionBestDescribeYou,
      name,
      mobile,
      email,
      monthlyImport_Export
    });

    // Save the remittance document to the database
    const result = await remittance.save();
    res.status(201).json({ message: 'Remittance created successfully', data: result });
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    res.status(500).json({ message: 'Internal server error' });
  }
};

// Get all remittances
exports.getAllRemittances = async (req, res) => {
  try {
    // Fetch all remittance documents from the database
    const remittances = await Remittance.find();
    res.status(200).json({ data: remittances });
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    res.status(500).json({ message: 'Internal server error' });
  }
};

// Update a remittance by ID
exports.updateRemittanceById = async (req, res) => {
  try {
    const id = req.params.id; // Get the ID from the request parameters
    const updateData = req.body; // Get the update data from the request body

    // Use the model's findByIdAndUpdate method to update the document by ID
    const result = await Remittance.findByIdAndUpdate(id, updateData, { new: true });

    if (result) {
      res.status(200).json({ message: 'Remittance updated successfully', data: result });
    } else {
      res.status(404).json({ message: 'Remittance not found' });
    }
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    res.status(500).json({ message: 'Internal server error' });
  }
};

// Delete a remittance by ID
exports.deleteRemittanceById = async (req, res) => {
  try {
    const id = req.params.id; // Get the ID from the request parameters

    // Use the model's findByIdAndDelete method to delete the document by ID
    const result = await Remittance.findByIdAndDelete(id);

    if (result) {
      res.status(200).json({ message: 'Remittance deleted successfully' });
    } else {
      res.status(404).json({ message: 'Remittance not found' });
    }
  } catch (error) {
    console.error(error); // Log the error for debugging purposes
    res.status(500).json({ message: 'Internal server error' });
  }
};

const express = require("express");
const router = express.Router();
const userController = require("../controller/beneficiary");

router.get("/", userController.convertCurrencyccc);


module.exports = router;
